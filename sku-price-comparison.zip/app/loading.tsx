import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function Loading() {
  return (
    <main className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-800 mb-6">Optics Price Comparison</h1>

        <Card className="bg-white shadow-sm p-8">
          <div className="flex flex-col items-center justify-center">
            <Loader2 className="h-8 w-8 text-blue-600 animate-spin mb-4" />
            <p className="text-slate-600">Loading results...</p>
          </div>
        </Card>
      </div>
    </main>
  )
}

