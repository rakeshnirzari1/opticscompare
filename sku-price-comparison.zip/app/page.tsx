import { SearchForm } from "@/components/search-form"
import { ResultsTable } from "@/components/results-table"
import { searchProducts } from "@/lib/search-products"

export default async function Home({
  searchParams,
}: {
  searchParams: { sku?: string }
}) {
  const sku = searchParams.sku
  const results = sku ? await searchProducts(sku) : null

  return (
    <main className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-800 mb-6">Optics Price Comparison</h1>
        <SearchForm initialSku={sku} />

        {results && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold text-slate-700 mb-4">Results for SKU: {sku}</h2>
            <ResultsTable results={results} />
          </div>
        )}
      </div>
    </main>
  )
}

