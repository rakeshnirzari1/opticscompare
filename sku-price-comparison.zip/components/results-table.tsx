import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { ProductResult } from "@/lib/types"

export function ResultsTable({ results }: { results: ProductResult[] }) {
  if (!results.length) {
    return (
      <div className="p-6 text-center bg-white rounded-lg border border-slate-200">
        <p className="text-slate-600">No results found for this SKU.</p>
      </div>
    )
  }

  return (
    <div className="overflow-x-auto">
      <Card className="bg-white shadow-sm">
        <div className="min-w-full divide-y divide-slate-200">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-100">
              <tr>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider"
                >
                  Store
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider"
                >
                  Price
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider"
                >
                  Stock Status
                </th>
                <th
                  scope="col"
                  className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider"
                >
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {results.map((result, index) => (
                <tr key={index} className="hover:bg-slate-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-slate-900">{result.store}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-900 font-medium">{result.price}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <StockBadge status={result.stockStatus} />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    {result.url ? (
                      <Button
                        variant="outline"
                        size="sm"
                        className="text-blue-600 hover:text-blue-800 border-blue-200 hover:border-blue-300"
                        asChild
                      >
                        <a href={result.url} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="h-4 w-4 mr-1" />
                          View
                        </a>
                      </Button>
                    ) : (
                      <span className="text-slate-400 text-sm">Not available</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}

function StockBadge({ status }: { status: string }) {
  if (!status)
    return (
      <Badge variant="outline" className="text-slate-500">
        Unknown
      </Badge>
    )

  const lowerStatus = status.toLowerCase()

  if (lowerStatus.includes("in stock") || lowerStatus.includes("available")) {
    return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">{status}</Badge>
  } else if (lowerStatus.includes("out of stock") || lowerStatus.includes("unavailable")) {
    return (
      <Badge variant="outline" className="text-red-600 border-red-200">
        {status}
      </Badge>
    )
  } else if (lowerStatus.includes("pre-order") || lowerStatus.includes("backorder")) {
    return <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">{status}</Badge>
  }

  return (
    <Badge variant="outline" className="text-slate-600">
      {status}
    </Badge>
  )
}

