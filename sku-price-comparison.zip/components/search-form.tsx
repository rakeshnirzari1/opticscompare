"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Search, Loader2 } from "lucide-react"

export function SearchForm({ initialSku = "" }: { initialSku?: string }) {
  const [sku, setSku] = useState(initialSku)
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()

  // Reset loading state when results are displayed
  useEffect(() => {
    // If we have a SKU parameter, we've completed a search
    if (searchParams.has("sku")) {
      // Use a short timeout to ensure the loading state is visible briefly
      const timer = setTimeout(() => {
        setIsLoading(false)
      }, 1000)

      return () => clearTimeout(timer)
    }
  }, [searchParams])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (sku.trim()) {
      setIsLoading(true)
      router.push(`/?sku=${encodeURIComponent(sku.trim())}`)
    }
  }

  return (
    <>
      <Card className="bg-white shadow-sm">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg text-slate-700">Search for a product SKU</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
            <div className="flex-1">
              <Input
                type="text"
                placeholder="Enter SKU number..."
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                className="w-full"
                disabled={isLoading}
              />
            </div>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={isLoading}>
              {isLoading ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Search className="h-4 w-4 mr-2" />}
              {isLoading ? "Searching..." : "Search"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {isLoading && (
        <div className="mt-4 p-4 bg-blue-50 border border-blue-100 rounded-md flex items-center justify-center">
          <div className="flex items-center space-x-2">
            <div className="h-3 w-3 bg-blue-600 rounded-full animate-pulse"></div>
            <div className="h-3 w-3 bg-blue-600 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }}></div>
            <div className="h-3 w-3 bg-blue-600 rounded-full animate-pulse" style={{ animationDelay: "0.4s" }}></div>
          </div>
          <span className="ml-3 text-blue-800">Searching for SKU: {sku}...</span>
        </div>
      )}
    </>
  )
}

