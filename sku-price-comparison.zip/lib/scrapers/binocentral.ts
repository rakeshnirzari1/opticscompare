import { load } from "cheerio"

interface BinocentralResult {
  price: string
  stockStatus: string
  url: string | null
}

export async function getBinocentralData(sku: string): Promise<BinocentralResult> {
  try {
    // First search for the product
    const searchUrl = `https://binocentral.com.au/catalogsearch/result/?q=${encodeURIComponent(sku)}`
    const searchResponse = await fetch(searchUrl, { next: { revalidate: 3600 } })

    if (!searchResponse.ok) {
      throw new Error(`Failed to fetch from Binocentral search: ${searchResponse.status}`)
    }

    const searchHtml = await searchResponse.text()
    const $ = load(searchHtml)

    // Find the product link
    const productLinkElement = $(".product-item-link").first()
    if (!productLinkElement.length) {
      return {
        price: "Not found",
        stockStatus: "Not found",
        url: null,
      }
    }

    const productUrl = productLinkElement.attr("href")
    if (!productUrl) {
      return {
        price: "Link not found",
        stockStatus: "Unknown",
        url: null,
      }
    }

    // Fetch the product page
    const productResponse = await fetch(productUrl, { next: { revalidate: 3600 } })

    if (!productResponse.ok) {
      throw new Error(`Failed to fetch from Binocentral product page: ${productResponse.status}`)
    }

    const productHtml = await productResponse.text()
    const $product = load(productHtml)

    // Extract stock information
    const stockElement = $product(".stock")
    const stockStatus = stockElement.length ? stockElement.text().trim() : "Unknown"

    // Extract pricing information
    const priceElement = $product(".price-container.price-final_price")
    const priceWrapper = priceElement.find(".price-wrapper")
    const priceAmount = priceWrapper.attr("data-price-amount") || ""
    const price = priceAmount ? `$${priceAmount}` : "Price not available"

    return {
      price,
      stockStatus,
      url: productUrl,
    }
  } catch (error) {
    console.error(`Error fetching Binocentral data for SKU ${sku}:`, error)
    return {
      price: "Error",
      stockStatus: "Error",
      url: null,
    }
  }
}

