import { load } from "cheerio"

interface BintelResult {
  price: string
  stockStatus: string
  url: string | null
}

export async function getBintelData(sku: string): Promise<BintelResult> {
  try {
    const searchUrl = `https://bintel.com.au/search?q=${encodeURIComponent(sku)}`
    const response = await fetch(searchUrl, { next: { revalidate: 3600 } })

    if (!response.ok) {
      throw new Error(`Failed to fetch from Bintel: ${response.status}`)
    }

    const html = await response.text()
    const $ = load(html)

    // Find the first product
    const productItem = $(".productitem").first()

    if (!productItem.length) {
      return {
        price: "Not found",
        stockStatus: "Not found",
        url: null,
      }
    }

    // Extract price using the specific price container and money span
    const priceContainer = productItem.find(".price__current[data-price-container]")
    const priceElement = priceContainer.find("span.money[data-price]")
    const price = priceElement.length ? priceElement.text().trim() : "Price not available"

    // Extract stock status - look for the span with green color
    let stockStatus = "Unknown"

    // Check for "Sold out" label
    const soldOutLabel = productItem.find(".productitem--badge.badge--soldout")
    if (soldOutLabel.length) {
      stockStatus = "Sold out"
    } else {
      // Look for green text indicating in stock
      const stockElements = productItem.find("span")
      stockElements.each((i, el) => {
        const style = $(el).attr("style")
        if (style && style.includes("color: green")) {
          stockStatus = $(el).text().trim()
          return false // Break the loop
        }
      })

      // If we didn't find a green span, try the product-stock-level class
      if (stockStatus === "Unknown") {
        const stockElement = productItem.find(".product-stock-level")
        if (stockElement.length) {
          stockStatus = stockElement.text().trim()
        }
      }
    }

    // Get the product URL for the "View" link
    const productUrl = productItem.find(".productitem--title a").attr("href")
    const fullUrl = productUrl ? `https://bintel.com.au${productUrl}` : searchUrl

    return {
      price,
      stockStatus,
      url: fullUrl,
    }
  } catch (error) {
    console.error(`Error fetching Bintel data for SKU ${sku}:`, error)
    return {
      price: "Error",
      stockStatus: "Error",
      url: null,
    }
  }
}

