import { load } from "cheerio"

interface SiriusOpticsResult {
  price: string
  stockStatus: string
  url: string | null
}

export async function getSiriusOpticsData(sku: string): Promise<SiriusOpticsResult> {
  try {
    const searchUrl = `https://www.sirius-optics.com.au/catalogsearch/result/?cat=0&q=${encodeURIComponent(sku)}`

    // Use a longer timeout and follow redirects
    const response = await fetch(searchUrl, {
      next: { revalidate: 3600 },
      redirect: "follow",
    })

    if (!response.ok) {
      throw new Error(`Failed to fetch from Sirius Optics: ${response.status}`)
    }

    const html = await response.text()
    const $ = load(html)

    // Check if we're on a product page or search results page
    const isProductPage = $("body.catalog-product-view").length > 0

    if (isProductPage) {
      // We're on a product page - extract data directly
      const priceElement = $(".price").first()
      // Get only the first price (first occurrence of text)
      const priceText = priceElement.length ? priceElement.text().trim() : "Price not available"
      // Extract just the first price if there are multiple
      const price = priceText.split("AUD ")[1] ? "AUD " + priceText.split("AUD ")[1].split("AUD")[0].trim() : priceText

      const stockElement = $(".amstockstatus")
      const stockStatus = stockElement.length ? stockElement.text().trim() : "Unknown"

      return {
        price,
        stockStatus,
        // Always return the search URL for consistency
        url: searchUrl,
      }
    } else {
      // We're on search results - find the first product
      const productItem = $(".product-item").first()

      if (!productItem.length) {
        return {
          price: "Not found",
          stockStatus: "Not found",
          url: searchUrl,
        }
      }

      // Get the product URL to fetch the product page
      const productUrl = productItem.find(".product-item-link").attr("href")

      if (!productUrl) {
        return {
          price: "Link not found",
          stockStatus: "Unknown",
          url: searchUrl,
        }
      }

      // Fetch the product page to get accurate price and stock
      const productResponse = await fetch(productUrl, {
        next: { revalidate: 3600 },
      })

      if (!productResponse.ok) {
        throw new Error(`Failed to fetch Sirius Optics product page: ${productResponse.status}`)
      }

      const productHtml = await productResponse.text()
      const $product = load(productHtml)

      const priceElement = $product(".price").first()
      // Get only the first price (first occurrence of text)
      const priceText = priceElement.length ? priceElement.text().trim() : "Price not available"
      // Extract just the first price if there are multiple
      const price = priceText.split("AUD ")[1] ? "AUD " + priceText.split("AUD ")[1].split("AUD")[0].trim() : priceText

      const stockElement = $product(".amstockstatus")
      const stockStatus = stockElement.length ? stockElement.text().trim() : "Unknown"

      return {
        price,
        stockStatus,
        // Always return the search URL for consistency
        url: searchUrl,
      }
    }
  } catch (error) {
    console.error(`Error fetching Sirius Optics data for SKU ${sku}:`, error)
    return {
      price: "Error",
      stockStatus: "Error",
      url: null,
    }
  }
}

