import type { ProductResult } from "./types"
import { getBinocentralData } from "./scrapers/binocentral"
import { getBintelData } from "./scrapers/bintel"
import { getSiriusOpticsData } from "./scrapers/sirius-optics"

export async function searchProducts(sku: string): Promise<ProductResult[]> {
  try {
    // Run all scrapers in parallel
    const [binocentralResult, bintelResult, siriusResult] = await Promise.all([
      getBinocentralData(sku).catch((error) => {
        console.error("Error fetching from Binocentral:", error)
        return null
      }),
      getBintelData(sku).catch((error) => {
        console.error("Error fetching from Bintel:", error)
        return null
      }),
      getSiriusOpticsData(sku).catch((error) => {
        console.error("Error fetching from Sirius Optics:", error)
        return null
      }),
    ])

    const results: ProductResult[] = []

    if (binocentralResult) {
      results.push({
        store: "Binocentral",
        price: binocentralResult.price,
        stockStatus: binocentralResult.stockStatus,
        url: binocentralResult.url,
      })
    }

    if (bintelResult) {
      results.push({
        store: "Bintel",
        price: bintelResult.price,
        stockStatus: bintelResult.stockStatus,
        url: bintelResult.url,
      })
    }

    if (siriusResult) {
      results.push({
        store: "Sirius Optics",
        price: siriusResult.price,
        stockStatus: siriusResult.stockStatus,
        url: siriusResult.url,
      })
    }

    return results
  } catch (error) {
    console.error("Error searching products:", error)
    return []
  }
}

