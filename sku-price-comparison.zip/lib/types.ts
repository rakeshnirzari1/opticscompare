export interface ProductResult {
  store: string
  price: string
  stockStatus: string
  url: string | null
}

